import { Box, Image, Text, Tag, Flex } from "@chakra-ui/react";

// RecipeCard component
function RecipeCard({ recipe, onClick }) {
  // Destructure recipe data
  const {
    label,
    image,
    dietLabels,
    cautions,
    mealType,
    dishType,
    healthLabels,
  } = recipe;

  // Only show specific health labels (Vegan or Vegetarian)
  const showHealthLabels = healthLabels.filter((label) =>
    ["Vegan", "Vegetarian"].includes(label)
  );

  // Utility function to convert text to Title
  const toTitleCase = (str) =>
    str?.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());

  return (
    <Box
      bg="white"
      borderRadius="lg"
      boxShadow="md"
      overflow="hidden"
      cursor="pointer"
      transition="transform 0.3s"
      // Slight zoom on hover
      _hover={{ transform: "scale(1.03)" }}
      width="100%"
      // Fixed height on mobile
      height={["450px", "auto", "auto"]}
      onClick={onClick}
    >
      {/* Recipe Image */}
      <Image
        src={image}
        alt={label}
        width="100%"
        height="180px"
        objectFit="cover"
      />

      {/* Recipe Details Container */}
      <Box p={3} textAlign="center" w="100%">
        {/* Meal Type Label */}
        <Text
          fontSize="xs"
          color="gray.500"
          fontWeight="semibold"
          textTransform="uppercase"
        >
          {mealType?.[0] || "Meal"}
        </Text>

        {/* Recipe Title */}
        <Text fontWeight="bold" fontSize="md" mt={1} mb={1}>
          {label}
        </Text>

        {/* Health Labels (Vegan / Vegetarian) */}
        <Flex wrap="wrap" justify="center" gap={1} mb={2}>
          {showHealthLabels.map((label, index) => (
            <Tag
              key={index}
              size="sm"
              textTransform="uppercase"
              fontWeight="bold"
              colorScheme="purple"
              borderRadius="4px"
            >
              {toTitleCase(label)}
            </Tag>
          ))}
        </Flex>

        {/* Diet Labels */}
        <Flex wrap="wrap" justify="center" gap={1} mb={2}>
          {dietLabels.map((label, index) => (
            <Tag
              key={index}
              size="sm"
              textTransform="uppercase"
              fontWeight="bold"
              colorScheme="green"
              borderRadius="4px"
            >
              {toTitleCase(label)}
            </Tag>
          ))}
        </Flex>

        {/* Dish */}
        <Text fontSize="sm" fontWeight="600">
          <Text as="span" fontWeight="normal">
            Dish:
          </Text>{" "}
          {toTitleCase(dishType?.[0] || "N/A")}
        </Text>

        {/* Cautions */}
        <Text fontSize="sm" fontWeight="600" mt={1}>
          <Text as="span" fontWeight="normal">
            Cautions:
          </Text>
        </Text>

        {/* Caution Tags */}
        <Flex wrap="wrap" justify="center" gap={1} mt={1}>
          {cautions.length > 0 ? (
            cautions.map((caution, index) => (
              <Tag
                key={index}
                size="sm"
                textTransform="uppercase"
                fontWeight="bold"
                colorScheme="red"
                borderRadius="4px"
              >
                {toTitleCase(caution)}
              </Tag>
            ))
          ) : (
            <Text fontSize="xs" fontWeight="bold" color="gray.500">
              None
            </Text>
          )}
        </Flex>
      </Box>
    </Box>
  );
}

export default RecipeCard;
