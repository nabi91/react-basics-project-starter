import { useState, useEffect } from "react";
import { Box } from "@chakra-ui/react";
import RecipeListPage from "./pages/RecipeListPage";
import RecipePage from "./pages/RecipePage";
import { data } from "./utils/data";
import { Global } from "@emotion/react";

export function App() {
  // Track the currently selected recipe (null means no recipe selected)
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  //  Set the global background color when the component mounts
  useEffect(() => {
    document.body.style.backgroundColor = "#2162b3";
  }, []);

  return (
    <>
      {/* Global CSS to remove default spacing */}
      <Global
        styles={{
          html: { height: "100%", margin: 0, padding: 0 },
          body: { height: "100%", margin: 0, padding: 0, overflow: "auto" },
          "#root": { height: "100%", margin: 0, padding: 0 },
        }}
      />

      {/* Main container with full screen height and blue background */}
      <Box minH="100vh" bg="#2162b3">
        {/* Conditional rendering: show detail page or list page */}
        {selectedRecipe ? (
          <RecipePage
            recipe={selectedRecipe}
            onBack={() => setSelectedRecipe(null)}
            onLogoClick={() => setSelectedRecipe(null)} // Logo click add just for fun
          />
        ) : (
          // Select a recipe
          <RecipeListPage
            recipes={data.hits}
            onSelectRecipe={(recipe) => setSelectedRecipe(recipe)}
          />
        )}
      </Box>
    </>
  );
}

export default App;
