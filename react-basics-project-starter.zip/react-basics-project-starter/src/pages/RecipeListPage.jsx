import { useState } from "react";
import {
  Box,
  Input,
  SimpleGrid,
  Heading,
  Center,
  Text,
} from "@chakra-ui/react";
import RecipeCard from "../components/RecipeCard";

// RecipeListPage displays a searchable, responsive grid of recipes
function RecipeListPage({ recipes, onSelectRecipe }) {
  // State to hold the current search term from user input
  const [searchTerm, setSearchTerm] = useState("");

  // Filter recipes based on search input
  const filteredRecipes = recipes.filter((item) => {
    const term = searchTerm.toLowerCase().replace(/-/g, " ").trim();
    const recipe = item.recipe;

    // Match recipe name
    const nameMatch = recipe.label.toLowerCase().includes(term);

    // Match health labels
    const healthMatch = recipe.healthLabels.some((label) =>
      label.toLowerCase().replace(/-/g, " ").includes(term)
    );

    // Match diet labels
    const dietMatch = recipe.dietLabels.some((label) =>
      label.toLowerCase().replace(/-/g, " ").includes(term)
    );

    // Return true if any category matches the search term
    return nameMatch || healthMatch || dietMatch;
  });

  return (
    <Box minH="100vh" px={[4, 6, 10]}>
      <Box maxW="1200px" mx="auto" py="40px">
        {/* Page Title */}
        <Center mb={6}>
          <Heading color="white" fontSize="3xl" fontWeight="800">
            Winc Recipe Checker
          </Heading>
        </Center>

        {/* Search Input Field */}
        <Center mb={10}>
          <Input
            placeholder="Search recipes "
            value={searchTerm}
            // Update state as user types
            onChange={(e) => setSearchTerm(e.target.value)}
            bg="white"
            width="100%"
            maxW="450px"
            focusBorderColor="teal.500"
          />
        </Center>

        {/* Recipe Grid or No Result Message */}
        {filteredRecipes.length === 0 ? (
          <Center>
            <Text fontSize="lg" fontWeight="bold" color="white">
              No results found
            </Text>
          </Center>
        ) : (
          <SimpleGrid columns={[1, 2, 3, 4]} spacing={9}>
            {filteredRecipes.map((item) => (
              <RecipeCard
                key={item.recipe.label}
                recipe={item.recipe}
                // Trigger selection callback
                onClick={() => onSelectRecipe(item.recipe)}
              />
            ))}
          </SimpleGrid>
        )}
      </Box>
    </Box>
  );
}

export default RecipeListPage;
