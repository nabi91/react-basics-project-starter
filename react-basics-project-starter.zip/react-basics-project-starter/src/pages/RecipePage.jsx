import {
  Box,
  Text,
  Heading,
  Image,
  Badge,
  Wrap,
  WrapItem,
  List,
  ListItem,
  Flex,
} from "@chakra-ui/react";
import wincLogo from "../assets/winc-log.png";

// RecipePage displays full recipe details in a styled layout
function RecipePage({ recipe, onBack, onLogoClick }) {
  // If no recipe is selected, render nothing
  if (!recipe) return null;

  // Destructure relevant fields from the recipe object
  const {
    label,
    image,
    mealType,
    totalTime,
    yield: servings,
    ingredientLines,
    healthLabels,
    dietLabels,
    cautions,
    totalNutrients,
  } = recipe;

  // Helper function to format nutrient values (rounded with unit)
  const getNutrient = (nutrient) =>
    nutrient ? `${Math.round(nutrient.quantity)} ${nutrient.unit}` : "N/A";

  return (
    //  Outer wrapper
    <Box bg="#047AB" minH="100vh" overflowY="auto" py={0} px={4}>
      {/* Main container */}
      <Box
        bg="#ffffff"
        maxW="800px"
        w="100%"
        minH="100vh"
        mx="auto"
        color="black"
        boxShadow="md"
        pb={8}
      >
        {/* Header, back button, logo */}
        <Flex justify="space-between" align="center" px={8} py={2}>
          {/*  Back button */}
          <Text
            cursor="pointer"
            onClick={onBack}
            fontSize="2xl"
            color="gray.600"
          >
            ‹
          </Text>

          {/* Logo */}
          <Box flex="1" display="flex" justifyContent="center">
            <Box as="button" onClick={onLogoClick}>
              <Image
                src={wincLogo}
                alt="Winc Academy Logo"
                width="55px"
                cursor="pointer"
              />
            </Box>
          </Box>
          <Box width="24px" />
        </Flex>

        {/* Recipe image */}
        <Image
          src={image}
          alt={label}
          mb={6}
          w="100%"
          h="280px"
          objectFit="cover"
        />

        {/* Content layout: two columns on desktop, stacked on mobile */}
        <Flex
          direction={{ base: "column", md: "row" }}
          px={9}
          align="flex-start"
          gap={9}
        >
          {/* LEFT SIDE — Basic info and ingredients */}
          <Box flex="1" minW="280px" mb={6}>
            {/* Meal type */}
            <Text fontSize="sm" color="gray.500" fontWeight="600" mb={1}>
              {mealType?.[0]?.toUpperCase()}
            </Text>

            {/* Title */}
            <Heading as="h2" size="md" fontWeight={600} mb={2}>
              {label}
            </Heading>

            {/* Time and servings */}
            <Text>Total cooking time: {totalTime} Minutes</Text>
            <Text mb={4}>Servings: {servings}</Text>

            {/* Ingredients list */}
            <Text fontWeight="600" mb={2}>
              Ingredients:
            </Text>
            <List spacing={2} fontWeight={300}>
              {ingredientLines.map((item, idx) => (
                <ListItem key={idx}>{item}</ListItem>
              ))}
            </List>
          </Box>

          {/* RIGHT SIDE — Labels, cautions, nutrients */}
          <Box flex="1" minW="280px" mb={12}>
            {/* Health labels */}
            <Text fontWeight="500" mb={2}>
              Health labels:
            </Text>
            <Wrap mb={4}>
              {healthLabels.map((label) => (
                <WrapItem key={label}>
                  <Badge bg="purple.100" color="purple.900">
                    {label.toUpperCase()}
                  </Badge>
                </WrapItem>
              ))}
            </Wrap>

            {/* Diet labels */}
            <Text fontWeight="500" mb={2}>
              Diet:
            </Text>
            <Wrap mb={4}>
              {dietLabels.map((label) => (
                <WrapItem key={label}>
                  <Badge bg="green.100" color="green.900">
                    {label.toUpperCase()}
                  </Badge>
                </WrapItem>
              ))}
            </Wrap>

            {/* Caution labels */}
            {cautions.length > 0 && (
              <>
                <Text fontWeight="500" mb={2}>
                  Cautions:
                </Text>
                <Wrap mb={4}>
                  {cautions.map((label) => (
                    <WrapItem key={label}>
                      <Badge bg="red.100" color="red.900">
                        {label.toUpperCase()}
                      </Badge>
                    </WrapItem>
                  ))}
                </Wrap>
              </>
            )}

            {/* Nutritional values */}
            <Box mb={6}>
              <Text fontWeight="500" mb={2}>
                Total nutrients:
              </Text>

              {/* Grid of nutrients */}
              <Box width={280}>
                {/* Top row */}
                <Flex justify="space-between" mb={4}>
                  <Box textAlign="left">
                    <Text>{getNutrient(totalNutrients.ENERC_KCAL)}</Text>
                    <Text fontSize="xs" fontWeight="500">
                      CALORIES
                    </Text>
                  </Box>
                  <Box textAlign="left">
                    <Text>{getNutrient(totalNutrients.CHOCDF)}</Text>
                    <Text fontSize="xs" fontWeight="500">
                      CARBS
                    </Text>
                  </Box>
                  <Box textAlign="left">
                    <Text>{getNutrient(totalNutrients.PROCNT)}</Text>
                    <Text fontSize="xs" fontWeight="500">
                      PROTEIN
                    </Text>
                  </Box>
                  <Box textAlign="left">
                    <Text>{getNutrient(totalNutrients.FAT)}</Text>
                    <Text fontSize="xs" fontWeight="500">
                      FAT
                    </Text>
                  </Box>
                </Flex>

                {/* Bottom row */}
                <Flex justify="space-between">
                  <Box textAlign="left">
                    <Text>{getNutrient(totalNutrients.CHOLE)}</Text>
                    <Text fontSize="xs" fontWeight="500">
                      CHOLESTEROL
                    </Text>
                  </Box>
                  <Box textAlign="left">
                    <Text>{getNutrient(totalNutrients.NA)}</Text>
                    <Text fontSize="xs" fontWeight="500">
                      SODIUM
                    </Text>
                  </Box>
                </Flex>
              </Box>
            </Box>
          </Box>
        </Flex>
      </Box>
    </Box>
  );
}

export default RecipePage;
